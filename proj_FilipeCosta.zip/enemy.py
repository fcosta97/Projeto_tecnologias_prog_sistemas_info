import math
import random
from configs import *
from world import *

class Enemy():
    def __init__(self):
        self.__x = 50 # Window.WIDTH - random.randint(100, 300)
        self.__y = 50
        self.__img = Skins.ENEMY
        self.__health = 1
        self.__damage = 1

    def get_damage(self):
        return self.__damage
    
    # create group 
    @staticmethod
    def create_group(quantity):
        enemies = []

        for number in range(quantity):
            enemies.append(Enemy())

        return enemies
    
    # move towards player
    def move_towards_player(self, player):
        if self.hits(player):
            player.hurt(self.get_damage())

        # Find direction vector (dx, dy) between enemy and player.
        direction_x = player.get_x() - self.__x

        direction_y = player.get_y() - self.__y

        distance = math.hypot(direction_x, direction_y)

        # Normalize.
        direction_x = direction_x / distance

        direction_y = direction_y / distance

        # Move along this normalized vector towards the player at current speed.
        self.__x += direction_x * WorldSettings.VELOCITY
        self.__y += direction_y * WorldSettings.VELOCITY



    # group move towards player
    @staticmethod
    def move_group_towards_player(enemy_group, player):
        for enemy in enemy_group:
            enemy.move_towards_player(player)

    #collides
    def collides_with(self, who):
        return who.get_overlaping_area(self.__img, self.__x, self.__y) > 0
    
    # group collides
    @staticmethod
    def group_collides_with(enemy_group, player):
        for enemy in enemy_group:
            enemy.collides_with(player)
    
    def get_overlaping_area(self, image, offset_x, offset_y):
        self_mask = pygame.mask.from_surface(self.__img)
        who_mask = pygame.mask.from_surface(image)
        return who_mask.overlap_area(self_mask, [self.__x - offset_x, self.__y - offset_y])
    
    def get_health(self):
        return self.__health
    
    def hurt(self, damage):
        self.__health -= damage
    
    def hits(self, player):
        return self.collides_with(player)
    
    @staticmethod
    def group_hits(enemy_group, player):
        for enemy in enemy_group:
            if enemy.hits():
                player.hurt(enemy.get_damage())

    def adjust(self, x, y):
        self.__x -= x
        self.__y -= y

    @staticmethod
    def adjust_group(enemy_group, x, y):
        for enemy in enemy_group:
            enemy.adjust(x, y)

    def draw(self, player_x, player_y, surface):

        rel_x = round(player_x - self.__x)
        rel_y = round(player_y - self.__y)

        angle = round((180 / math.pi) * -math.atan2(rel_y , rel_x))
        rotated_image = pygame.transform.rotate(self.__img, angle)
        new_rect = rotated_image.get_rect(center = self.__img.get_rect(center = (self.__x, self.__y)).center)

        surface.blit(rotated_image, new_rect)

    # draw group
    def draw_group(enemy_group, player, surface):
        for enemy in enemy_group:
            enemy.draw(player.get_x(), player.get_y(), surface)