# Projeto_tecnologias_prog_sistemas_info

# Tema:

Jogo 2D que consiste em disparar balas para tentar acertar em inimigos que estão constantemente a tentar apanhar o jogador. Estes inimigos podem deixar cair frutas que recuperam a vida do jogador e acrescentam um número de pontos quando este colide com as mesmas.

# Objetivos do jogo:

## Objetivos do jogador:
  
- Fugir ou matar os inimigos;
- Apanhar o maior número de frutas possível.

## Objetivos dos inimigos:
  
  - Apanhar ou matar o jogador;
  
# Observações:

- Jogo em 2D;
- Vista de cima;
- Existem 3 tipos de personagem diferentes:
	- O jogador;
	- O inimigo;
	- A fruta.
- Os inimigos devem aparecer fora do ecrã e depois movimentarem-se em direção ao jogador;
- Quando a bala colide com um inimigo, ambos desaparecem;
- Se o jogador disparar e acertar num inimigo fora do ecrã, a fruta não deve de aparecer;
- O jogador faz o disparo ao clicar no botão esquerdo do rato e a bala move-se em direção à posição do cursor quando foi feito o click;
- Existem pelo menos 4 classes:
	- Classe Jogador;
	- Classe Bala;
	- Classe Inimigo;
	- Classe Fruta.
- Estas classes podem herdar uma classe Elementos;
